<?php
$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

$Errors = [];
$Data = [];

if($_SERVER["REQUEST_METHOD"] == "POST"){
	if(empty($_GET['email'])){
		$Errors['email'] = "Email is Required";
	}
	
	if(empty($_GET['firstname'])){
		$Errors['firstname'] = "FirstName is Required";
	}
	
	if(empty($_GET['lastname'])){
		$Errors['lastname'] = "LastName is Required";
	}
	

	if(empty($_GET['password'])){
		$Errors['password'] = "Password is Required";
	}	
	
	if (!empty($errors)) {
        $data["status"] = false;
        $data["message"] = "Please fill all fields";
    } else {
        $database = "touristappdb";
        $username = "root";
        $password = "";
        $host = "localhost";

        $connection = mysqli_connect($host, $username, $password, $database);
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        } else {
            $firstName = $_POST['firstname'];
            $LasttName = $_POST['lastname'];
            $password = $_POST['password'];
            // $role = $_POST['role'];
            $Email = $_POST['email'];

            $query = "SELECT * FROM USERS WHERE Email = '$Email'";
            $result = mysqli_query($connection, $query);
			$records = [];
        
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$records+= $row;
				}
				$data["status"] = false;
				$data["message"] = "User Already Exists";
				
			} else{
				$firstName = $_POST['firstname'];
				$lastName = $_POST['lastname'];
				$password = $_POST['password'];
				$role = "User";
				$email = $_POST['email'];

				$query = "INSERT INTO `USERS`(`firstname`, `lastname`, `password`, `role`, `email`) VALUES ('$firstName','$lastName','$password','$role','$email')";
				$result = mysqli_query($connection, $query);
								
				if ($result) {
                $data["status"] = true;
                $data["message"] = "Registration Successful";
				} else {
					$data["status"] = false;
					$data["message"] = mysqli_error($connection);
				}		
			}	          
        }
    }
}

echo json_encode($data);
exit();
