<?php
$Errors = [];
$Data = [];

$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

if ($_SERVER["REQUEST_METHOD"] == "GET") {

	$database = "touristappdb";
	$username = "root";
	$password = "";
	$host = "localhost";

	$connection = mysqli_connect($host, $username, $password, $database);
	if (!$connection) {
		die("Connection failed: " . mysqli_connect_error());
	} else {
		$query = 'SELECT * FROM `hotels`';
		$result = mysqli_query($connection, $query);
		$records = [];

		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$records[] = $row;
			}
			$data["status"] = true;
			$data["message"] = $records;
		} else {
			$data["status"] = false;
			$data["message"] = "Failed to get Hotels";
		}
	}
}


echo json_encode($data);
exit();
