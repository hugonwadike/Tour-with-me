<?php

$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

$Errors = [];
$Data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST['Name'])) {
		$Errors['Name'] = "Name is Required";
	}

	if (empty($_POST['Address'])) {
		$Errors['Address'] = "Address is Required";
	}

	if (empty($_POST['Description'])) {
		$Errors['Description'] = "Description is Required";
	}


	if (empty($_POST['Image'])) {
		$Errors['Image'] = "Picture is Required";
	}


	if (!empty($errors)) {
		$data["status"] = false;
		$data["message"] = $errors;
	} else {
		$database = "touristappdb";
		$username = "root";
		$password = "";
		$host = "localhost";

		$connection = mysqli_connect($host, $username, $password, $database);
		if (!$connection) {
			die("Connection failed: " . mysqli_connect_error());
		} else {
			$Name = $_POST['Name'];
			$Address = $_POST['Address'];
			$Description = $_POST['Description'];
			$Picture = $_POST['Image'];

			$query = "INSERT INTO `HOTELS` (`name`, `address`, `comments`,`description`, `picture`) VALUES ('$Name','$Address',' ','$Description','$Picture')";
			$result = mysqli_query($connection, $query);


			if ($result) {
				$data["status"] = true;
				$data["message"] = "Successful";
			} else {
				$data["status"] = false;
				$data["message"] = mysqli_error($connection);
			}
		}
	}
}

echo json_encode($data);
exit();
