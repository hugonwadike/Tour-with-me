<?php
$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

// header('Access-Control-Allow-Origin: *')
// header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
// header("Access-Control-Allow-Headers: *");

$Errors = [];
$Data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	// header('Access-Control-Allow-Origin: *')
	// header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
	// header('Access-Control-Allow-Headers: *');


	if (empty($_REQUEST['Email'])) {
		$Errors['Email'] = "Email is Required";
	}

	if (empty($_REQUEST['Password'])) {
		$Errors['Password'] = "Password is Required";
	}

	if (!empty($errors)) {
		$data["status"] = false;
		$data["message"] = $errors;
	} else {
		$database = "touristappdb";
		$username = "root";
		$password = "";
		$host = "localhost";

		$connection = mysqli_connect($host, $username, $password, $database);
		if (!$connection) {
			die("Connection failed: " . mysqli_connect_error());
		} else {

			$email = $_POST['email'];
			$password = $_POST['password'];

			// $query = "SELECT JSON_ARRAYAGG(JSON_OBJECT('idUsers', idUsers, 'Role',Role,'Password', Password )) FROM USERS WHERE Email = '$email' ";
			$query = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
			$result = mysqli_query($connection, $query);
			$records = [];
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$records[] = $row;
				}
				$data["status"] = true;
				$data["message"] = $records;
			}
		}
	}
}

echo json_encode($data);
exit();
