<?php  
$Errors = [];
$Data = [];
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (empty($_GET['HotelId'])) {
        $Errors['HotelId'] = "UserId is Required";
    }
    if (empty($_GET['DelHotelId'])) {
        $Errors['DelHotelId'] = "DelUserId is Required";
    }
    if (!empty($errors)) {
        $data["status"] = false;
        $data["message"] = $errors;
    } else {
        $database = "touristappdb";
        $username = "root";
        $password = "";
        $host = "localhost";
        $connection = mysqli_connect($host, $username, $password, $database);
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        } else {
            $hotelId = $_GET['hotelid'];
            // $delHotelId = $_GET['deletedHotel'];            
            $query = "SELECT * FROM Hotels WHERE idHotels = '$hotelId'";
            $result = mysqli_query($connection, $query);
            $records = [];
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $records[] = $row;
                }
                // if ($records[0]['Role'] == "Admin" || "User") {                   
                     $query = "DELETE FROM Hotels WHERE idHotels = '$hotelId'";
                    $result = mysqli_query($connection, $query);
                    if ($result) {
                        $data["status"] = true;
                        $data["message"] = "Post Deleted Successfully";
                    } else {
                        $data["status"] = false;
                        $data["message"] = "Cannot delete, try again";
                    }
                // } else {                //     $data["status"] = false;                //     $data["message"] = "Unauthorised Action";                // }           
             } else {
                $data["status"] = false;
                $data["message"] = "Failed to get hotel";
            }
        }
    }
}
echo json_encode($data);
exit();