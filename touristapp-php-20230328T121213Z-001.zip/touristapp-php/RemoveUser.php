<?php

$Errors = [];
$Data = [];


if ($_SERVER["REQUEST_METHOD"] == "GET") {
	if (empty($_GET['UserId'])) {
		$Errors['UserId'] = "UserId is Required";
	}
	if (empty($_GET['DelUserId'])) {
		$Errors['DelUserId'] = "DelUserId is Required";
	}

	if (!empty($errors)) {
		$data["status"] = false;
		$data["message"] = $errors;
	} else {
		$database = "touristappdb";
		$username = "root";
		$password = "";
		$host = "localhost";

		$connection = mysqli_connect($host, $username, $password, $database);

		if (!$connection) {
			die("Connection failed: " . mysqli_connect_error());
		} else {
			$userId = $_GET['userId'];
			$delUserId = $_GET['deletedUser'];


			$query = "SELECT * FROM Users WHERE idUsers = '$userId'";
			$result = mysqli_query($connection, $query);
			$records = [];

			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$records[] = $row;
				}

				if ($records[0]['Role'] == "Admin") {

					$query = "DELETE FROM Users WHERE idUsers = '$delUserId'";
					$result = mysqli_query($connection, $query);


					if ($result) {
						$data["status"] = true;
						$data["message"] = "User Deleted Successfully";
					} else {
						$data["status"] = false;
						$data["message"] = "Cannot delete, try again";
					}
				} else {
					$data["status"] = false;
					$data["message"] = "Unauthorised Action";
				}
			} else {
				$data["status"] = false;
				$data["message"] = "Failed to get hotel";
			}
		}
	}
}

echo json_encode($data);
exit();
