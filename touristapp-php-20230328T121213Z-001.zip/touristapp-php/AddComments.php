<?php

$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

$Errors = [];
$Data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST['HotelId'])) {
		$Errors['HotelId'] = "HotelId is Required";
	}

	if (empty($_POST['Comment'])) {
		$Errors['Comment'] = "Comment is Required";
	}

	if (!empty($errors)) {
		$data["status"] = false;
		$data["message"] = $errors;
	} else {
		$database = "touristappdb";
		$username = "root";
		$password = "";
		$host = "localhost";

		$connection = mysqli_connect($host, $username, $password, $database);
		if (!$connection) {
			die("Connection failed: " . mysqli_connect_error());
		} else {

			$hotelId = $_POST['hotelId'];
			$comment = $_POST['comment'];

			$query = "SELECT Comments FROM HOTELS WHERE idHotels = '$hotelId'";
			$result = mysqli_query($connection, $query);
			$records = [];

			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$records[] = $row;
				}
				$newComment = $records[0]["Comments"] . "," . $comment;
				$query = "UPDATE Hotels set Comments  = '$newComment' WHERE idHotels = '$hotelId'";
				$newresult = mysqli_query($connection, $query);

				if ($newresult) {
					$data["status"] = true;
					$data["message"] = "Comment Added Successully";
				} else {
					$data["status"] = false;
					$data["message"] = "Failed to Add Comment";
				}
			} else {

				$data["status"] = true;
				$data["message"] = "Hotel Does not Exist";
			}
		}
	}
}

echo json_encode($data);
exit();
